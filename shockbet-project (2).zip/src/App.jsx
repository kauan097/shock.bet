
import { useState, useEffect } from "react";

export default function App() {
  const [page, setPage] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [saldo, setSaldo] = useState(0);
  const [mensagem, setMensagem] = useState("");

  const handleLogin = () => {
    localStorage.setItem("shockbet_user", JSON.stringify({ email, saldo: 100 }));
    setSaldo(100);
    setPage("dashboard");
  };

  const handleRegister = () => {
    localStorage.setItem("shockbet_user", JSON.stringify({ email, saldo: 100 }));
    setSaldo(100);
    setPage("dashboard");
  };

  const handleLogout = () => {
    localStorage.removeItem("shockbet_user");
    setEmail("");
    setPassword("");
    setPage("login");
  };

  const apostarNumero = () => {
    const numeroSorteado = Math.floor(Math.random() * 10) + 1;
    const meuNumero = Math.floor(Math.random() * 10) + 1;
    if (meuNumero === numeroSorteado) {
      setSaldo(saldo + 50);
      setMensagem(`Parabéns! Você acertou o número ${meuNumero} e ganhou R$ 50!`);
    } else {
      setSaldo(saldo - 10);
      setMensagem(`Você escolheu ${meuNumero}, mas o número era ${numeroSorteado}. Perdeu R$ 10.`);
    }
  };

  const jogarRoleta = () => {
    const resultado = Math.floor(Math.random() * 37);
    const minhaAposta = Math.floor(Math.random() * 37);
    if (resultado === minhaAposta) {
      setSaldo(saldo + 100);
      setMensagem(`Roleta: Você apostou ${minhaAposta}, caiu ${resultado} — ganhou R$ 100!`);
    } else {
      setSaldo(saldo - 20);
      setMensagem(`Roleta: Você apostou ${minhaAposta}, caiu ${resultado} — perdeu R$ 20.`);
    }
  };

  useEffect(() => {
    const user = localStorage.getItem("shockbet_user");
    if (user) {
      const data = JSON.parse(user);
      setEmail(data.email);
      setSaldo(data.saldo);
      setPage("dashboard");
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("shockbet_user", JSON.stringify({ email, saldo }));
  }, [saldo]);

  return (
    <div style={{ minHeight: "100vh", padding: 20, background: "linear-gradient(to bottom right, black, #333)", color: "white" }}>
      {page === "login" && (
        <>
          <h2>Entrar na ShockBet</h2>
          <input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <br />
          <input placeholder="Senha" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <br />
          <button onClick={handleLogin}>Entrar</button>
          <button onClick={() => setPage("register")}>Criar conta</button>
        </>
      )}

      {page === "register" && (
        <>
          <h2>Criar conta na ShockBet</h2>
          <input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <br />
          <input placeholder="Senha" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <br />
          <button onClick={handleRegister}>Cadastrar</button>
          <button onClick={() => setPage("login")}>Já tem conta? Entrar</button>
        </>
      )}

      {page === "dashboard" && (
        <>
          <h2>Bem-vindo à ShockBet!</h2>
          <p>Email: {email}</p>
          <p>Saldo: R$ {saldo.toFixed(2)}</p>
          <button onClick={apostarNumero}>Apostar em número (1 a 10)</button>
          <button onClick={jogarRoleta}>Jogar roleta (0 a 36)</button>
          {mensagem && <p>{mensagem}</p>}
          <button onClick={handleLogout}>Sair</button>
        </>
      )}
    </div>
  );
}
